<?php

Event::listen('rainlab.user.beforeAuthenticate', 'PilihanGanda\Core\Listeners\User@checkUserType');
Event::listen('rainlab.user.login', 'PilihanGanda\Core\Listeners\User@afterLogin');


Event::listen('rainlab.user.register', 'PilihanGanda\Core\Listeners\User@handleRegisteredUser');
