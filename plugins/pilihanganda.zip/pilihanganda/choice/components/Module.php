<?php namespace PilihanGanda\Choice\Components;

use Cms\Classes\ComponentBase;
use PilihanGanda\Choice\Models\{Questionaire,Question,Answer,Survei,Response};
use PilihanGanda\Choice\Classes\ModuleManager;

class Module extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Module Component',
            'description' => 'No description provided yet...'
        ];
    }

    public function init()
    {
        
        $question   = $this->addComponent(
            'Responsiv\Uploader\Components\FileUploader',
            'questionFiles',
            [
                'fileTypes'             => ".jpg, .jpeg, .png, .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx",
                'placeholderText'       => "Drag and drop file here or Browse File",
                'deferredBinding'       => true      
            ]
        );
        $question->bindModel('files', ($this->property('questionId') ? Question::find((int)$this->property('questionId')) : new Question));
        
        $answer   = $this->addComponent(
            'Responsiv\Uploader\Components\FileUploader',
            'answerFiles',
            [
                'fileTypes'             => ".jpg, .jpeg, .png, .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx",
                'placeholderText'       => "Drag and drop file here or Browse File",
                'deferredBinding'       => true      
            ]
        );
        $answer->bindModel('files', ($this->property('answerId') ? Question::find((int)$this->property('answerId')) : new Answer));
    }

    public function defineProperties()
    {
        return [
            'type' => [
                'title'             => 'Define Submodule Question',
                'description'       => 'This used for manage every modules',
                'default'           => 'modules',
                'type'              => 'string',
                'validationPattern' => '^[0-9]+$',
            ],
            'questionaire_id' => [
                'title'             => 'Define Submodule Questionaire',
                'description'       => 'This used for manage every modules',
                'default'           => 'modules',
                'type'              => 'integer',
                'validationPattern' => '^[0-9]+$',
            ],
        //     'questionId' => [
        //         'title'             => 'Define Submodule Questionaire',
        //         'description'       => 'This used for manage every modules',
        //         'default'           => 'modules',
        //         'type'              => 'integer',
        //         'validationPattern' => '^[0-9]+$',
        //     ],
        //     'answerId' => [
        //         'title'             => 'Define Submodule Questionaire',
        //         'description'       => 'This used for manage every modules',
        //         'default'           => 'modules',
        //         'type'              => 'integer',
        //         'validationPattern' => '^[0-9]+$',
        //    ]
        ];
    }

    public function getListofQuestions()
    {
        $items = Question::where('questionaire_id', (int)$this->property('questionaire_id'))->get();
        return $items;
    }

    public function get()
    {
        $data = (new ModuleManager($this->property('type')))->get();
        return $data;
    }

    public function onCreateAnswer()
    {
        $data = post();
        $answer = new Answer;
        $answer->fill($data);
        $answer->save(null, post('_session_key'));
        
        \Flash::success('Data has been Changed');
        return \Redirect::to('modules/questions/'.$answer->question->questionaire->id);

    }

    public function onCreateQuestion()
    {
        $data = post();
        $question = new Question;
        $question->fill($data);

        $question->save(null, post('_session_key'));
        if (!$question) {
            \Flash::error('Data has not been created');
        }
        else {
            \Flash::success('Data has been Changed');
            return \Redirect::to('/modules');
        }
    }

    public function onCreateForm()
    {
        $data = post();
        $module = (new ModuleManager($this->property('type')))->createOrUpdate($data);
        \Flash::success('Data has been Changed');
        return \Redirect::to('/modules');
    }
}
