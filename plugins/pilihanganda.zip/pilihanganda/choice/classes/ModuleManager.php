<?php namespace PilihanGanda\Choice\Classes;

use PilihanGanda\Choice\Models\{Questionaire,Question,Answer,Survei,Response};
use Db, Validator;
use Carbon\Carbon;

class ModuleManager 
{
    private $availableTypes = [ "module","question","answer"];
    private $type;

    public function __construct(string $type) {
        $this->type = $type;
    }

    public function createOrUpdate(Array $data)
    {
        try {
            Db::beginTransaction();
            if ($this->type == 'module') {
                $validator = Validator::make(
                    $data,[
                        'title'     => 'required',
                        'purpose'   => 'required'
                    ]    
                );

                $model = Questionaire::updateOrInsert([
                    'id'    => array_get($data,'id')
                ],
                [
                    'title'     => array_get($data,'title'),
                    'purpose'   => array_get($data,'purpose'),
                    'is_active' => array_get($data,'is_active') ? array_get($data,'is_active') : 0,
                    'slug'      => str_slug(array_get($data,'title'))
                ]);
            }
            Db::commit();
            return $model;
        } catch (\Exception $e) {
            Db::rollBack();
            throw $e;
        }
    }

    public function get()
    {
        if ($this->type == 'module') {
            return Questionaire::orderBy('id', 'DESC')->get()->map(function($item){
                return [
                    'id'        => $item->id,
                    'title'     => $item->title,
                    'purpose'   => $item->purpose,
                    'slug'      => $item->slug,
                    'is_active' => $item->is_active,
                    'logo'      => $item->logo,
                    'questions' => $item->questions
                ];
            });
        }
    }
}

