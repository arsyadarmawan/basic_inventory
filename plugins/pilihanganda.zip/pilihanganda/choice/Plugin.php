<?php namespace Pilihanganda\Choice;

use Backend;
use System\Classes\PluginBase;

/**
 * choice Plugin Information File
 */
class Plugin extends PluginBase
{
    /**
     * Returns information about this plugin.
     *
     * @return array
     */
    public function pluginDetails()
    {
        return [
            'name'        => 'choice',
            'description' => 'No description provided yet...',
            'author'      => 'pilihanganda',
            'icon'        => 'icon-leaf'
        ];
    }

    /**
     * Register method, called when the plugin is first registered.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Boot method, called right before the request route.
     *
     * @return array
     */
    public function boot()
    {

    }

    /**
     * Registers any front-end components implemented in this plugin.
     *
     * @return array
     */
    public function registerComponents()
    {


        return [
            'Pilihanganda\Choice\Components\Module' => 'module',
        ];
    }

    /**
     * Registers any back-end permissions used by this plugin.
     *
     * @return array
     */
    public function registerPermissions()
    {
        return []; // Remove this line to activate

        return [
            'pilihanganda.choice.some_permission' => [
                'tab' => 'choice',
                'label' => 'Some permission'
            ],
        ];
    }

    /**
     * Registers back-end navigation items for this plugin.
     *
     * @return array
     */
    public function registerNavigation()
    {


        return [
            'choice' => [
                'label'       => 'Questionaire',
                'url'         => Backend::url('pilihanganda/choice/questionaires'),
                'icon'        => 'icon-check-square',
                'permissions' => ['pilihanganda.choice.*'],
                'order'       => 500,
                'sideMenu'    => [
                    'questionaires' => [
                        'label'       => 'Modules',
                        'icon'        => 'icon-certificate',
                        'url'         => Backend::url('pilihanganda/choice/questionaires'),
                        'permissions' => ['choice.questionaires.views'],
                    ],
                    'questions' => [
                        'label'       => 'Questions',
                        'icon'        => 'icon-check-circle',
                        'url'         => Backend::url('pilihanganda/choice/questions'),
                        'permissions' => ['choice.questionaires.views'],
                    ],
                    'answers' => [
                        'label'       => 'Answers',
                        'icon'        => 'icon-share-square',
                        'url'         => Backend::url('pilihanganda/choice/answers'),
                        'permissions' => ['choice.questionaires.views'],
                    ],
                    'surveis' => [
                        'label'       => 'Surveys',
                        'icon'        => 'icon-code',
                        'url'         => Backend::url('pilihanganda/choice/surveis'),
                        'permissions' => ['choice.questionaires.views'],
                    ],
                    'responses' => [
                        'label'       => 'Responses',
                        'icon'        => 'icon-cogs',
                        'url'         => Backend::url('pilihanganda/choice/responses'),
                        'permissions' => ['choice.questionaires.views'],
                    ],
                ]
            ],
        ];
    }
}
