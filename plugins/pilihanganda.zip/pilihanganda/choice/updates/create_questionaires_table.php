<?php namespace Pilihanganda\Choice\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateQuestionairesTable extends Migration
{
    public function up()
    {
        Schema::create('pilihanganda_choice_questionaires', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('title')->nullable();
            $table->string('purpose')->nullable();
            $table->string('slug')->nullable();
            $table->boolean('is_active')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('pilihanganda_choice_questionaires');
    }
}
