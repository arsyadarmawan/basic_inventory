<?php namespace Pilihanganda\Choice\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateAnswersTable extends Migration
{
    public function up()
    {
        Schema::create('pilihanganda_choice_answers', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->unsignedInteger('question_id')->nullable();
            $table->string('answer')->nullable();
            $table->unsignedDecimal('value',12,0)->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('pilihanganda_choice_answers');
    }
}
